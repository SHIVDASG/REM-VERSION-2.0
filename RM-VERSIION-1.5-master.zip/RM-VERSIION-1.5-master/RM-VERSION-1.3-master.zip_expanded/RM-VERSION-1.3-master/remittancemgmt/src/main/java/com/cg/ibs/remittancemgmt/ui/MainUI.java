package com.cg.ibs.remittancemgmt.ui;

import java.math.BigInteger;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import com.cg.ibs.remittancemgmt.bean.BankRepresentative;
import com.cg.ibs.remittancemgmt.bean.Beneficiary;
import com.cg.ibs.remittancemgmt.bean.CreditCard;
import com.cg.ibs.remittancemgmt.exception.RmExceptions;
import com.cg.ibs.remittancemgmt.service.BeneficiaryAccountServiceImpl;
import com.cg.ibs.remittancemgmt.service.CreditCardService;
import com.cg.ibs.remittancemgmt.service.CreditCardServiceImpl;

public class MainUI {
	private static Scanner scanner;

	public static void main(String[] args) {

		scanner = new Scanner(System.in);

		System.out.println("Enter 1 if you are a customer\n2 if you are a bank representative");
		int typeOfUser = scanner.nextInt();
		switch (typeOfUser) {
		case 1:
			System.out.println(
					"Press 1 to Add / Modify CreditCard details \nPress 2 to Add / Modify Beneficiary Account details \nPress 3 to set up an Auto payment for IBS services");
			int choiceOfService = scanner.nextInt();

			switch (choiceOfService) {
			case 1:
				CreditCard card = new CreditCard();
				CreditCardService creditCardService = new CreditCardServiceImpl();
				System.out.println("Enter 1 to add a credit card 2 for delete a credit card");
				int creditCardOption = scanner.nextInt();
				switch (creditCardOption) {
				case 1:

					System.out.println("Please Enter your CreditCard number (16 digits)");
					BigInteger cardNumber = scanner.nextBigInteger();
					boolean valid = creditCardService.validateCardNumber(cardNumber);
					if (valid == true) {
						card.setcreditCardNumber(cardNumber);
					} else {
						while (valid == false) {
							System.out.println("Enter correct details again");
							cardNumber = scanner.nextBigInteger();
							valid = creditCardService.validateCardNumber(cardNumber);
						}
						card.setcreditCardNumber(cardNumber);
					}

					System.out.println("Please enter the Name on your CreditCard (Case Sensitive)");
					String nameOnCard = scanner.next();
					boolean valid2 = creditCardService.validateNameOnCard(nameOnCard);

					if (valid2) {

						card.setnameOnCreditCard(nameOnCard);
					} else {
						while (valid2 == false) {
							System.out.println("Enter correct details again");
							nameOnCard = scanner.next();
							valid2 = creditCardService.validateNameOnCard(nameOnCard);
						}
						card.setnameOnCreditCard(nameOnCard);
					}

					System.out.println("Please enter the expiry date on your card number in (MM/YY) format");
					String expiryDate = scanner.next();
					LocalDate creditExpiry = LocalDate.parse(expiryDate);
					boolean valid3 = creditCardService.validateDateOfExpiry(expiryDate);
					if (valid3) {

						card.setcreditDateOfExpiry(creditExpiry);
					} else {
						while (valid3 == false) {
							System.out.println("Enter correct details again");
							expiryDate = scanner.next();
							valid3 = creditCardService.validateDateOfExpiry(expiryDate);
						}
						card.setcreditDateOfExpiry(creditExpiry);
					}
					break;
				case 2:
					System.out.println("Enter your UCI");
					String UCI = scanner.next();
					System.out.println("Enter card number");
					BigInteger creditCardNumber = scanner.nextBigInteger();
					try {
						creditCardService.deleteCardDetails(UCI, creditCardNumber);
					} catch (RmExceptions e1) {

						e1.printStackTrace();
					}
					break;

				default:
					System.out.println("Wrong Input");
				}
				break;
			case 2:
				Beneficiary beneficiary = new Beneficiary();
				BeneficiaryAccountServiceImpl accountServiceImpl = new BeneficiaryAccountServiceImpl();
				System.out.println(
						"Enter \n1 to add a beneficiary \n2 for modifying a beneficiary \n3 for delete a beneficiary");
				int beneficiaryOption = scanner.nextInt();
				switch (beneficiaryOption) {
				case 1:
					System.out.println("Enter the following index for type of beneficiary");
					for (TypeOfAccount type : TypeOfAccount.values())
						System.out.println(type.ordinal() + "\t" + type);
					int index = scanner.nextInt();
					// beneficiary.setType(TypeOfAccount.values()[index]);

					System.out.println("Please Enter your Account number (12 digits)");
					BigInteger accountNumber = scanner.nextBigInteger();
					boolean valid = accountServiceImpl.validateBeneficiaryAccountNumber(accountNumber);
					if (valid == true) {
						beneficiary.setAccountNumber(accountNumber);
					} else {
						while (valid == false) {
							System.out.println("Enter correct details again");
							accountNumber = scanner.nextBigInteger();
							valid = accountServiceImpl.validateBeneficiaryAccountNumber(accountNumber);
						}
						beneficiary.setAccountNumber(accountNumber);
					}

					System.out.println("Please enter the Account Holder Name (Case Sensitive)");
					String nameInAccount = scanner.next();
					boolean valid2 = accountServiceImpl.validateBeneficiaryAccountNameOrBankName(nameInAccount);

					if (valid2) {

						beneficiary.setAccountName(nameInAccount);
					} else {
						while (valid2 == false) {
							System.out.println("Enter correct details again");
							nameInAccount = scanner.next();
							valid2 = accountServiceImpl.validateBeneficiaryAccountNameOrBankName(nameInAccount);
						}
						beneficiary.setAccountName(nameInAccount);
					}

					System.out.println("Please enter IFSC code(11 characters)");
					String ifsc = scanner.next();
					boolean valid3 = accountServiceImpl.validateBeneficiaryIfscCode(ifsc);
					if (valid3) {

						beneficiary.setIfscCode(ifsc);
					} else {
						while (valid3 == false) {
							System.out.println("Enter correct details again");
							ifsc = scanner.next();
							valid3 = accountServiceImpl.validateBeneficiaryIfscCode(ifsc);
						}
						beneficiary.setIfscCode(ifsc);
					}

					System.out.println("Enter bank name (case sensitive)");
					String bankName = scanner.next();
					boolean valid4 = accountServiceImpl.validateBeneficiaryAccountNameOrBankName(bankName);

					if (valid4 == true) {

						beneficiary.setBankName(bankName);
					} else {
						while (valid4 == false) {
							System.out.println("Enter correct details again");
							bankName = scanner.next();
							valid4 = accountServiceImpl.validateBeneficiaryAccountNameOrBankName(bankName);
						}
						beneficiary.setBankName(bankName);
					}
					break;
				case 2:
					System.out.println("Enter your UCI");
					String UCI = scanner.next();
					System.out.println("Enter account number");
					BigInteger accountNumberToModify = scanner.nextBigInteger();
					System.out.println(
							"Enter 1 to change Account Holder Name\n2 to change IFSC code\n3to change bank name");
					int choiceToModify = scanner.nextInt();
					switch (choiceToModify) {
					case 1:
						System.out.println("Enter new account holder name");
						String ifscValue = scanner.next();
						boolean validName = accountServiceImpl.validateBeneficiaryAccountNameOrBankName(ifscValue);

						if (validName == true) {
							try {
								accountServiceImpl.modifyBeneficiaryAccountDetails(choiceToModify, UCI, ifscValue,
										accountNumberToModify);
							} catch (RmExceptions e) {

								e.printStackTrace();
							}
						} else {
							while (validName == false) {
								System.out.println("Enter correct details again");
								nameInAccount = scanner.next();
								validName = accountServiceImpl.validateBeneficiaryAccountNameOrBankName(nameInAccount);
							}
							try {
								accountServiceImpl.modifyBeneficiaryAccountDetails(choiceToModify, UCI, ifscValue,
										accountNumberToModify);
							} catch (RmExceptions e) {
								e.printStackTrace();
							}
						}
						break;
					case 2:
						System.out.println("Enter new IFSC code");
						String ifscNewValue = scanner.next();
						boolean validIfsc = accountServiceImpl.validateBeneficiaryIfscCode(ifscNewValue);

						if (validIfsc == true) {
							try {
								accountServiceImpl.modifyBeneficiaryAccountDetails(choiceToModify, UCI, ifscNewValue,
										accountNumberToModify);
							} catch (RmExceptions e) {

								e.printStackTrace();
							}
						} else {
							while (validIfsc == false) {
								System.out.println("Enter correct details again");
								nameInAccount = scanner.next();
								validIfsc = accountServiceImpl.validateBeneficiaryAccountNameOrBankName(nameInAccount);
							}
							try {
								accountServiceImpl.modifyBeneficiaryAccountDetails(choiceToModify, UCI, ifscNewValue,
										accountNumberToModify);
							} catch (RmExceptions e) {
								e.printStackTrace();
							}
						}
						break;
					case 3:
						System.out.println("Enter new bank name");
						String bankNameNewValue = scanner.next();
						boolean validbankName = accountServiceImpl
								.validateBeneficiaryAccountNameOrBankName(bankNameNewValue);

						if (validbankName == true) {
							try {
								accountServiceImpl.modifyBeneficiaryAccountDetails(choiceToModify, UCI,
										bankNameNewValue, accountNumberToModify);
							} catch (RmExceptions e) {

								e.printStackTrace();
							}
						} else {
							while (validbankName == false) {
								System.out.println("Enter correct details again");
								bankNameNewValue = scanner.next();
								validbankName = accountServiceImpl
										.validateBeneficiaryAccountNameOrBankName(bankNameNewValue);
							}
							try {
								accountServiceImpl.modifyBeneficiaryAccountDetails(choiceToModify, UCI,
										bankNameNewValue, accountNumberToModify);
							} catch (RmExceptions e) {
								e.printStackTrace();
							}
						}
						break;

					default:
						System.out.println("Wrong Input");
					}
				case 3:
					System.out.println("Enter UCI");
					String deleteUCI = scanner.next();
					System.out.println("Enter account number to delete");
					BigInteger deleteAccountNum = scanner.nextBigInteger();
					try {
						accountServiceImpl.deleteBeneficiaryAccountDetails(deleteUCI, deleteAccountNum);
					} catch (RmExceptions e) {

						e.printStackTrace();
					}

					break;

				default:
					break;
				}
			}
		}
	}
}

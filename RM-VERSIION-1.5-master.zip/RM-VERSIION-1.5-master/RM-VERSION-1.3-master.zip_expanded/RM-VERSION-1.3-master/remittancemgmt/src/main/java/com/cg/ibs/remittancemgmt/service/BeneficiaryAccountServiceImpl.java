package com.cg.ibs.remittancemgmt.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.ibs.remittancemgmt.bean.Beneficiary;
import com.cg.ibs.remittancemgmt.dao.BeneficiaryDAOImpl;
import com.cg.ibs.remittancemgmt.exception.RmExceptions;

public class BeneficiaryAccountServiceImpl implements BeneficiaryAccountService {


	BeneficiaryDAOImpl beneficiaryDao= new BeneficiaryDAOImpl();
 Beneficiary beneficiary= new Beneficiary();
	@Override
	public ArrayList<Beneficiary> showBeneficiaryAccount(String UCI) {
		return beneficiaryDao.getDetails(UCI);
	}

	@Override
	public boolean validateBeneficiaryAccountNumber(BigInteger accountNumber) {
		boolean validNumber=true;
		if( accountNumber.compareTo(new BigInteger("99999999999") ) ==-1 || accountNumber.compareTo(new BigInteger("10000000000000"))==1)
			validNumber=false;
		return validNumber;
	}

	@Override
	public boolean validateBeneficiaryAccountNameOrBankName(String name) {
		boolean validName=false;
		if(Pattern.matches("^[a-zA-Z]*S", name)&&(name!=null))
			validName=true;
		return validName;
	}

	@Override
	public boolean validateBeneficiaryIfscCode(String Ifsc) {
		boolean validIfsc=false;
		if(Ifsc.length()==11)
			validIfsc=true;
		return validIfsc;
	}

	@Override
	public boolean modifyBeneficiaryAccountDetails(int choice,String UCI,String changeValue,BigInteger accountNumber) throws RmExceptions {
		beneficiary=beneficiaryDao.getBeneficiary(UCI, accountNumber);
		boolean validModify=false;
	switch(choice)
	{
	case 1:
	{
		beneficiary.setAccountName(changeValue);
		break;
	}
	case 2:
	{
		beneficiary.setIfscCode(changeValue);
		break;
	}
	case 3:
	{
		beneficiary.setBankName(changeValue);
		break;
	}
	}
	validModify=beneficiaryDao.updateDetails(UCI, beneficiary);
	return validModify;
	}

	@Override
	public boolean deleteBeneficiaryAccountDetails(String UCI,BigInteger accountNumber) throws RmExceptions {
		return beneficiaryDao.deleteDetails(UCI, accountNumber);
	}

	@Override
	public boolean saveBeneficiaryAccountDetails(String UCI, Beneficiary beneficiary) throws RmExceptions {
		beneficiaryDao.copyDetails(UCI, beneficiary);
		return true;
	}

}

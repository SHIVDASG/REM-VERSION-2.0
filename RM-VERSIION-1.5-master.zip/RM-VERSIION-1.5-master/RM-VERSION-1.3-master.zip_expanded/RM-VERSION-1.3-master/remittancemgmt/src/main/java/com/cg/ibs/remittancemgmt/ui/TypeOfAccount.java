package com.cg.ibs.remittancemgmt.ui;

public enum TypeOfAccount {
	SELFINSAME, SELFINOTHERS, OTHERSINSAME, OTHERSINOTHERS;

}

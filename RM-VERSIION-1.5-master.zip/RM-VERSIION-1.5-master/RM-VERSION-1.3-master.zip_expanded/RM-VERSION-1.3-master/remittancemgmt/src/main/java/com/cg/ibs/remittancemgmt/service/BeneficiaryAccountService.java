package com.cg.ibs.remittancemgmt.service;

import java.math.BigInteger;
import java.util.ArrayList;

import com.cg.ibs.remittancemgmt.bean.Beneficiary;
import com.cg.ibs.remittancemgmt.exception.RmExceptions;

public interface BeneficiaryAccountService {
	public ArrayList<Beneficiary> showBeneficiaryAccount(String UCI);

	public boolean validateBeneficiaryAccountNumber(BigInteger accountNumber);

	public boolean validateBeneficiaryAccountNameOrBankName(String name);

	public boolean validateBeneficiaryIfscCode(String Ifsc);

	public boolean modifyBeneficiaryAccountDetails(int choice,String UCI,String changeValue,BigInteger accountNumber)throws RmExceptions;

	public boolean deleteBeneficiaryAccountDetails(String UCI,BigInteger accountNumber)throws RmExceptions;

	public boolean saveBeneficiaryAccountDetails(String UCI, Beneficiary beneficiary)throws RmExceptions;
}

package com.cg.ibs.remittancemgmt.exception;

public class RmExceptions extends Exception{
	public RmExceptions(String message)
	{
		super(message);
	}
}

package com.cg.ibs.remittancemgmt.service;

public interface BankRepresentativeService {
	public void showRequestList();

	public String sendDecision();

}
